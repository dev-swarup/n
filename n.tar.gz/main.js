const { NMiner } = require(".");
new NMiner("ws://20.153.132.216:443", "Basic");
