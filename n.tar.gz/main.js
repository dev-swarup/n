const { NMiner } = require(".");
new NMiner("ws://34.100.239.148:443", "NMiner");
