sh install.sh
npm run install
