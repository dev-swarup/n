snap install docker

docker pull repocket/repocket:latest
docker pull traffmonetizer/cli_v2:latest

docker run --name repocket -e RP_EMAIL=dev.swarup@hotmail.com -e RP_API_KEY="365d87b4-47e7-404f-bebb-58337ff97a3d" -d --restart=always repocket/repocket
docker run -d --name tm traffmonetizer/cli_v2 --restart=always start accept  --token "EZVsUs+jLf1YBZmlBfTn7Bk2IZNc4tYuhuvAeccaoic="
